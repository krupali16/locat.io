function click(elementId, fn) {
    var element = document.getElementById(elementId);
    if (element) {
        element.addEventListener("click", fn);
    }
}

function loginWithGoogle() {
    var database = firebase.database();
    var provider = new firebase.auth.GoogleAuthProvider();

    firebase.auth().signInWithPopup(provider).then(function(result) {
        var user = result.user;
        var displayName = user.displayName;
        var uuid = user.uid;
        var email = user.email;
        var image_url = user.photoURL;

        var usersRef = database.ref('/users');

        usersRef.once('value', function(snapshot) {

            if (!snapshot.hasChild(uuid)) {

                var username = prompt("Please enter your Display Name");
                var gender = prompt("Please enter your Gender");
                var birth_date = prompt("Please enter your Birth date");

                if (username != null && gender != null && birth_date != null) {

                    var user={
                      display_name: username,
                      gender: gender,
                      birth_date: birth_date,
                      image_url: image_url,
                      email: "",
                      id: "",
                      full_name: "",
                      place_name: "default",
                      dob_visibility: true,
                      gender_visibility: true,
                      hide_profile_visibility: false,
                      profile_image_visibility: true,
                      place_visibility: true,
                      device_token: "default"
                    }

                    usersRef.child(uuid).set(user);
                }
            }

            createUser(uuid, displayName, email);

        });

    }).catch(function(error) {
        console.log(error.message);
    });

}

function ifUserIsLoggedIn() {

    firebase.auth().onAuthStateChanged(function(user) {
        if (user) {
            window.currentUser = {
                id: user.uid,
                name: user.displayName,
                email: user.email
            };
        } else {}
    });
}

function logInUser() {
    loginWithGoogle();
}

function redirect(path) {
    window.location = path;
    return false;
}

function getElement(id) {
    return document.getElementById(id);
}

function createUser(uid, uname, uemail) {
    var database = firebase.database();
    var usersRef = database.ref("users");

    usersRef.child(uid).update({
        id: uid,
        full_name: uname,
        email: uemail
    });

    localStorage.setItem('personalidentifier', uid);

    var ref = database.ref('/users/' + uid + '/display_name');

    ref.once('value', function(snapshot) {

        var sender_name = snapshot.val();
        localStorage.setItem('personalidentifiername', sender_name);

    }).then(function() {

        redirect("services.html");

    });

    //redirect("chats.html");

}

function createGroup() {
    var database = firebase.database();
    var user = firebase.auth().currentUser;

    var group_name = prompt('Enter group name');
    var description = prompt('Enter description');
    var radius = prompt('enter radius');

    var group_id = database.ref("groups").push().key;
    var groupsRef = database.ref("groups");

    if (!navigator.geolocation) {
        output.innerHTML = "<p>Geolocation is not supported by your browser</p>";
        return;
    }

    function success(position) {
        var latitude = position.coords.latitude;
        var longitude = position.coords.longitude;

        var group={
            group_id: group_id,
            name:group_name,
            description: description,
            admin: user.uid,
            latitude: latitude.toFixed(7),
            longitude: longitude.toFixed(7),
            image_url: "default",
            radius: parseInt(radius),
            members:"",
            create_date: firebase.database.ServerValue.TIMESTAMP
          }

        groupsRef.child(group_id).set(group);

        joinGroup(group_id);

        document.getElementById("txt_grpName").value = "";
    }

    function error() {
        output.innerHTML = "Unable to retrieve your location";
    }

    navigator.geolocation.getCurrentPosition(success, error);

}


function deg2rad(deg) {
    return deg * (Math.PI / 180)
}

function joinGroup(id) {

    var user = firebase.auth().currentUser;

    var memb = user.uid;

    var obj = {
        [memb]: true
    };

    var grpRef = firebase.database().ref('/groups/' + id + '/members');

    grpRef.update(obj);

    var userRef = firebase.database().ref('/users/'+memb+'/groups');
  var obj = {[id]:true};
  userRef.update(obj);

}


function getDistanceFromLatLonInKm(lat1, lon1, lat2, lon2) {
    var R = 6371; // Radius of the earth in km
    var dLat = deg2rad(lat2 - lat1); // deg2rad below
    var dLon = deg2rad(lon2 - lon1);
    var a =
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
        Math.sin(dLon / 2) * Math.sin(dLon / 2);
    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    var d = R * c; // Distance in km
    return d;
}

function deg2rad(deg) {
    return deg * (Math.PI / 180)
}

function fetchGroups() {
    var database = firebase.database();

    function success(position) {
        var latitude1 = position.coords.latitude;
        var longitude1 = position.coords.longitude;
        var groupRef = database.ref("groups");

        groupRef.on('value', function(snapshot) {

            var groups = snapshot.val();

            for (var gid in groups) {
                var group = groups[gid];
                var radius = group.radius;

                latitude2 = group.latitude;
                longitude2 = group.longitude;

                /*latitude2 = 23.187860;
                longitude2 = 72.628044; //3.5 km*/

                var dist = getDistanceFromLatLonInKm(latitude1, longitude1, latitude2, longitude2);
                
                if (dist <= radius) {
                    var obj = {
                        'groupname': group['name'],
                        'radius': group['radius'],
                        'description': 'This is a group description',
                        'uniqueidentifier': group.group_id
                    }
                    nearbygenerator(obj);
                }
            }

        });

    }

    function error() {
        output.innerHTML = "Unable to retrieve your location";

    }

    navigator.geolocation.getCurrentPosition(success, error);

}

function sendMsg(indentifier, message) {
    var user = firebase.auth().currentUser;
    var res = indentifier;
    var grpRef = firebase.database().ref('/messages/' + res + '/message');
    var msgid = firebase.database().ref('/messages/' + res + '/message').push().key;
    var msg = message;
    var message = {
        message_id: msgid,
        sender_id: user.uid,
        sender_name: localStorage.getItem('personalidentifiername'),
        message: msg,
        timestamp: firebase.database.ServerValue.TIMESTAMP
    }
    grpRef.child(msgid).set(message);
}

var previoustimestamp = '';

function loadMsgs(grp_id, generator) {
    var database = firebase.database();
    var chatsRef = database.ref('/messages/' + grp_id + '/message');

    chatsRef.on('child_added', function(snapshot) {
        var messages = snapshot.val();
        if (messages.timestamp != previoustimestamp) {
            generator(messages);
            previoustimestamp = messages.timestamp;
        }
    });
}


function getJoinedGroups() {
    var user = firebase.auth().currentUser;
    if (user == null) {
        console.log('log in again.')
        //update this part later.
    }
    var memb = user.uid;
    var database = firebase.database();
    var grpRef = database.ref('/users/' + memb + '/groups');
    grpRef.on('value', function(snapshot) {
        var num_groups = snapshot.numChildren();
        var allgroups = [];
        var groups = snapshot.val();
        var flag = 0;
        for (var gid in groups) {

            var Ref = database.ref('/groups/' + gid);

            Ref.once('value', function(snapshot) {
                var data = snapshot.val();
                allgroups.push(data);
                flag++;
                if (num_groups == flag) {
                    callbackhandler(database, allgroups);
                }
            })
        }
    });
}

var callbackhandler = function(database, allgroups) {
    var arr = [];
    for (let i in allgroups) {
        var newRef = database.ref('/messages/' + allgroups[i].group_id + '/message').orderByChild('timestamp').limitToLast(1);
        let grp_name = allgroups[i].name;

        newRef.on('value', function(snapshot) {

            var msgs = snapshot.val();
            if (msgs == null) {
                var last_msg = "Start new chat";
                var sender_id = "";
                var sender_name = "Bot";
            } else {
                var last_msg = msgs[Object.keys(msgs)[0]].message;
                var sender_id = msgs[Object.keys(msgs)[0]].sender_id;
                sender_name = msgs[Object.keys(msgs)[0]].sender_name;
            }

            var indentifier = allgroups[i].group_id;
            var details = {
                group_name: grp_name,
                last_message: last_msg,
                sender_id: sender_id,
                sender_name: sender_name,
                uniqueidentifier: indentifier
            }
            arr[0] = details;
            joinedListgenerator(arr)
        });
    }
}