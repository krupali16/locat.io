click("signin-button",logInUser);

click("creategrp_button",createGroup);

click("fetchgrp_button",fetchGroups);

click("send_button",sendMsg);
