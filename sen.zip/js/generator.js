var nearbygenerator = function(object){
	var html = 
	'<li class="listcard nearbylist" title="tap to join the group" ' + "data-identifier=" + object['uniqueidentifier'] + '>' + 
		'<span class="listcard-image"><img src="resources/pic1.png"></span>' +
		'<div class="listcard-content">' + 
			'<span class="leftcontent">' + 
				'<span class="listcard-title">' + object['groupname'] +  '</span>' + 
				'<span class="listcard-preview">' + 
					'<strong>'+object['description']+'</strong> '+
				'</span>' + 
			'</span>'+
			'<span class="badge rightcontent radiusbadge">' + object['radius'] + ' km</span>'; + 
		'</div>' +
	'</li>'

	$('#lister>ul').append(html);
}


var joinedListgenerator = function(object){
		var htmlwithactive = 
			'<li class="listcard joinedlist active" ' + "data-identifier=" + object[0]['uniqueidentifier'] + '>' + 
				'<span class="listcard-image"><img src="resources/pic1.png"></span>' +
				'<div class="listcard-content">' + 
					'<span class="leftcontent">' + 
						'<span class="listcard-title">' + object[0]['group_name'] +  '</span>' + 
						'<span class="listcard-preview">' + 
							'<strong>'+object[0]['sender_name']+':</strong> '+ object[0]['last_message'] + 
						'</span>' + 
					'</span>'+
				'</div>' +
			'</li>';

			var htmlnotactive = 
			'<li class="listcard joinedlist" ' + "data-identifier=" + object[0]['uniqueidentifier'] + '>' + 
				'<span class="listcard-image"><img src="resources/pic1.png"></span>' +
				'<div class="listcard-content">' + 
					'<span class="leftcontent">' + 
						'<span class="listcard-title">' + object[0]['group_name'] +  '</span>' + 
						'<span class="listcard-preview">' + 
							'<strong>'+object[0]['sender_name']+':</strong> '+ object[0]['last_message'] + 
						'</span>' + 
					'</span>'+
				'</div>' +
			'</li>';

	if($('[data-identifier=' + object[0]['uniqueidentifier'] + ']').length>0){
		if($('[data-identifier=' + object[0]['uniqueidentifier'] + ']').hasClass('active')){
			$('[data-identifier=' + object[0]['uniqueidentifier'] + ']').remove();
			$('#lister>ul').prepend(htmlwithactive);
		}

		else{
			$('[data-identifier=' + object[0]['uniqueidentifier'] + ']').remove();
			$('#lister>ul').prepend(htmlnotactive);
		}
	}
	else{
		$('#lister>ul').append(htmlnotactive);
	}	
}


var messagesGenerator = function(object){
	if(localStorage.getItem('personalidentifier')!=object.sender_id){
		var html =
		'<div class="item left">'+
			'<div class="talk-bubble tri-right left-top bubbleleft">'+
			  '<div class="talktext">'+
			  	'<span class="displayname">' + object.sender_name + '</span>' +
			    '<p>' + object.message + '</p>' + 
			  '</div>'+
			'</div>' + 
		'</div>';
	}

	else{
		var html =
		'<div class="item right">'+
			'<div class="talk-bubble tri-right right-top bubbleright">'+
			  '<div class="talktext">'+
			  	'<span class="displayname">Me</span>' +
			    '<p>' + object.message + '</p>' + 
			  '</div>'+
			'</div>' + 
		'</div>';
	}

	$('.chat.scroll').append(html);
	document.getElementById('scrollheight').scrollTop = document.getElementById('scrollheight').scrollHeight;
}