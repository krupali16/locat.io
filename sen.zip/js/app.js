$(document).ready(function(){



	$(document).foundation();

	/*var today = new Date()
	$("#dobpicker").flatpickr({
		altInput: true,
		dateFormat: "d.m.Y",
    	maxDate: today.getDate() + "." + (parseInt(today.getMonth()) + parseInt(1)) +  '.' + parseInt(today.getFullYear()-13)
	});
*/

	$(document).on('click', '#sendbtn', function(){
		if($.trim($('#inputbar').val())!=''){
			sendMsg(localStorage.getItem('activeidentifier'), $('#inputbar').val())
		}
		$('#inputbar').val('')
	});


	$(document).on('click', '.nearbylist', function(){
		var groupid = $(this).attr('data-identifier')
		console.log(groupid)
		joinGroup(groupid);
		$('[data-tag=chat]').trigger('click');
	});


	$('#inputbar').keypress(function(e) {
	  if(e.which == 13) {
		if($.trim($('#inputbar').val())!=''){
			sendMsg(localStorage.getItem('activeidentifier'), $('#inputbar').val())
		}
		$('#inputbar').val('')
	  }
	});

	//swap display panes
	$(document).on('click', '.listcard.joinedlist', function(e){
		e.preventDefault();
		$('.pane-stack').hide();
		$('#pane2').show()
	});


	$(document).on('click', '.listcard.joinedlist', function(e){
		e.preventDefault();
		//$(this).find('.notificationbadge').remove()
		var identifier = $(this).attr('data-identifier')
		localStorage.setItem('activeidentifier', identifier)
		if($(this).hasClass('active')){
			console.log('do nothing')
		}
		else{
			console.log('do everthing')
			$('.chat.scroll').html('')
			$('.listcard').removeClass('active');
			$(this).addClass('active')
			loadMsgs(identifier,messagesGenerator);
		}
	});

	$(document).on('click', '#bottom-nav>div>div', function(){
		$('.pane-stack').hide(); //to hide chat right pane when other options are clicked.
		$('#bottom-nav>div>div').removeClass('activeMenu');
		$(this).addClass('activeMenu');


		if($(this).attr('data-tag')=="ask"){
			if($(this).find('ul').length==0){
				$('#lister').html('');
				$('#lister').append('<ul></ul>');
			}
			$('#lister>ul').html('');
			$('#pane1').show();
		}

		if($(this).attr('data-tag')=="nearby"){
			if($(this).find('ul').length==0){
				$('#lister').html('');
				$('#lister').append('<ul></ul>');
			}
			$('#lister>ul').html('');
			fetchGroups();
			$('#pane1').show();
		}

		else if($(this).attr('data-tag')=="chat"){
			if($(this).find('ul').length==0){
				$('#lister').html('');
				$('#lister').append('<ul></ul>');
			}
			$('#lister>ul').html('');
			getJoinedGroups();
			$('.chat.scroll').html('')
		}

		else if($(this).attr('data-tag')=="settings"){
			$('#lister').html('');
			$('#lister').append(settings)
			$('#pane4').show();
		}

	})



	
var settings = '<div class="profile">'+
'<div class="basic">'+
'<div class="userimg">'+
'<img src="http://placehold.it/120/120/">'+
'</div>'+
'<div class="username">'+
'Vishal Garg'+
'</div>'+
'<div class="userlocation">'+
'New Delhi, India'+
'</div>'+
'</div>'+
''+
'<div class="advanced">'+
''+
'<div class="strip">Set privacy control & visibility</div>'+
''+
''+
'<div class="grid-x">'+
'<div class="small-8 cell">Profile picture visibility</div>'+
'<div class="small-4 cell">'+
'<div class="switch">'+
'<input class="switch-input" id="exampleSwitch1" type="checkbox" name="exampleSwitch" data-toggle-all>'+
'<label class="switch-paddle" for="exampleSwitch1">'+
'<span class="show-for-sr">Toggle All</span>'+
'</label>'+
'</div>'+
'</div>'+
'</div>'+
''+
''+
'<div class="grid-x">'+
'<div class="small-8 cell">'+
'<select>'+
'<option value="">Gender</option>'+
'<option value="male">Male</option>'+
'<option value="female">Female</option>'+
'</select>'+
'</div>'+
'<div class="small-4 cell">'+
'<div class="switch">'+
'<input class="switch-input" id="switch5" type="checkbox" checked name="exampleSwitch" data-toggle-all>'+
'<label class="switch-paddle" for="switch5">'+
'<span class="show-for-sr">Toggle All</span>'+
'</label>'+
'</div>'+
'</div>'+
'</div>'+
''+
''+
'<div class="grid-x">'+
'<div class="small-8 cell">Real name visibility</div>'+
'<div class="small-4 cell">'+
'<div class="switch">'+
'<input class="switch-input" id="switch2" type="checkbox" name="exampleSwitch" data-toggle-all>'+
'<label class="switch-paddle" for="switch2">'+
'<span class="show-for-sr">Toggle All</span>'+
'</label>'+
'</div>'+
'</div>'+
'</div>'+
''+
'<div class="grid-x">'+
'<div class="small-8 cell">'+
'<input type="text" placeholder="College / Company / Institution" name="institution">'+
'</div>'+
'<div class="small-4 cell">'+
'<div class="switch">'+
'<input class="switch-input" id="switch3" type="checkbox" name="exampleSwitch" data-toggle-all>'+
'<label class="switch-paddle" for="switch3">'+
'<span class="show-for-sr">Toggle All</span>'+
'</label>'+
'</div>'+
'</div>'+
'</div>'+
''+
''+
'<div class="grid-x">'+
'<div class="small-8 cell">'+
'<input type="date" name="">'+
'</div>'+
'<div class="small-4 cell">'+
'<div class="switch">'+
'<input class="switch-input" id="switch4" type="checkbox" checked name="exampleSwitch" data-toggle-all>'+
'<label class="switch-paddle" for="switch4">'+
'<span class="show-for-sr">Toggle All</span>'+
'</label>'+
'</div>'+
'</div>'+
'</div>'+
''+
'</div>'+
''+
'<div class="buttons">'+
'<button type="button" class="button save">Save</button>'+
'<button type="button" class="button deactivate">Deactivate Account</button>'+
'</div>'+
''+
'</div>';
//end of onready
});